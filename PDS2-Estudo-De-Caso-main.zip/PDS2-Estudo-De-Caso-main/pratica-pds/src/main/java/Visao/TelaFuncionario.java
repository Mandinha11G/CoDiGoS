package Visao;

public class TelaFuncionario {

}
