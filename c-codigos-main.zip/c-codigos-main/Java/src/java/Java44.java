package java;

import java.util.Scanner;

public class Java44 {

	public static void main(String[] args) {

		   Scanner leitura = new Scanner(System.in);
           String[] vetor = {"A","M","A","N","D","A","L","V","E","S"};
           for (int i = 0; i <10; i++) {


           }


           System.out.println(vetor[vetor.length-1]);
           System.out.println(vetor.length);

   }

}
	