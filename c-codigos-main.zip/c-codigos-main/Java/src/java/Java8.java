package java;

public class Java8 {

	public static void main(String[] args) {

		 public Double calcabs(Double qtdLitros, Double precoLitros) {
		        if(qtdLitros == null) {

		    }

		    return qtdLitros * precoLitros;
		}
		
	}

}
