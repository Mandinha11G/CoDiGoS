package java;

//public class Metodo {
	
	//public FLoat NOMEQUALQUER (Float[] vetor) {
	//	Float soma = 0f;
	//	for( int i = 0; i < vetor.length; i ++){
	//	soma = soma + (vetor [i] * 8);
	//	}
	//	return soma;
//}

//}


