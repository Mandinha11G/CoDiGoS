package java;

import java.util.Scanner;

public class Java55 {

	public static void main(String[] args) {

		 Scanner s = new Scanner(System.in);

	        System.out.println("Isira quantidade litros");
	        String qtdLitros = s.nextLine();
	        System.out.println("Insira preço litro: ");
	        String precoLitro = s.nextLine();

	        if(!qtdLitros.isEmpty () && ! precoLitro.isEmpty()) {
	            // conversão
	            //chamar o metodo para caso o valor esteja vazio
	        }

	    }

	
	

}
