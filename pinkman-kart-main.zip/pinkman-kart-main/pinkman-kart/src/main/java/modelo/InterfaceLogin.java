package modelo;

public interface InterfaceLogin {
	

	public Funcionario consultarLogin(Funcionario usuario);

	Funcionario consultaFuncionario(Funcionario usuario);
	


}