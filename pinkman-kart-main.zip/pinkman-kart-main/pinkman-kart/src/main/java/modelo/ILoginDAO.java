package modelo;

public interface ILoginDAO {
	
	 public boolean autenticarLogin(String login, Long senha);

}
