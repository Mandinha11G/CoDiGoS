package modelo;

public class Cliente extends Pessoa {

	private Long telefone;

	public Long getTelefone() {
		return telefone;
	}

	public void setTelefone(Long telefone) {
		this.telefone = telefone;
	}

}
