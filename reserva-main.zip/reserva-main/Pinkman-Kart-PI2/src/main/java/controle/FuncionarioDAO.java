package controle;

public class FuncionarioDAO {

}
