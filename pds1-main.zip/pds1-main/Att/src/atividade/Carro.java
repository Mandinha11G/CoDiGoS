package atividade;

public class Carro extends Veiculo{
	
	
	public String placa;
	
	public void ligar() {
		
	}
	public void desligar() {
		
	}
	

}
