package atividade;

public class Bicicleta extends Veiculo {
	
	
}
