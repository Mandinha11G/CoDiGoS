package atividade;

public class Veiculo {

	public String marca;
	public String modelo;
	
	public void acelerar() {
		
	}
}
