package atv9;

import java.util.Scanner;

public class Atividade9 {

	public static void main(String[] args) {     
		    }

		    public Double calculadoraAbs(Double qtdLitros, Double precolitros, Double precototal) {
		        if(qtdLitros == null || precolitros == null) {
		            System.out.println("Valores nulos: ");
		        } else {
		            precototal = qtdLitros * precolitros;
		        }
		        return precototal;
		        
		    }
		    
		}
