package atv7;

import java.util.Scanner;

public class Atividade7 {

	public static void main(String[] args) {
		
		
	
        Scanner leitura = new Scanner(System.in);
        String[] vetor = {"A","M","A","N","D","A","L","V","E","S"};
        for (int i = 0; i <10; i++) {


        }

        System.out.println("O ultimo elemento do vetor é: ");
        System.out.println(vetor[vetor.length-1]);
        System.out.println("O tamanho do vetor é: ");
        System.out.println(vetor.length);
	}

}
