package atv1;

import java.util.Scanner;

public class Atividade1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	    
	         Scanner leitura = new Scanner(System.in);
	        
	           String nome = leitura.nextLine();
	           System.out.println(nome);
	                
	    }
	

	}

