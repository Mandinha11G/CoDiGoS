package aula;

public class Gato extends Animal{

	 public String mia;

	    public Gato() {

	    }

	    public Gato(String mia) {
	        this.mia = mia;
	    }

	    public String getmia() {
	        return mia;
	    }

	    public void setmia(String mia) {
	        this.mia = mia;
	    }
	}

