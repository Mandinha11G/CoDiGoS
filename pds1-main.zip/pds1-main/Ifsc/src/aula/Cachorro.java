package aula;

public class Cachorro extends Animal {
	
	public String late;

    public Cachorro() {

    }

    public Cachorro(String late) {
        this.late = late;
    }

    public String getlate() {
        return late;
    }

    public void setlate(String late) {
        this.late = late;
    }
}


