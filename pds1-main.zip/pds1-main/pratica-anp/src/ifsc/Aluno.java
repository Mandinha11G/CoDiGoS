package ifsc;
public class Aluno extends Pessoa {
	
	
    private Integer matricula;

    public Integer getMatricula() {
    	
        return matricula;
    }


    public void setMatricula(Integer matricula) {
        this.matricula = matricula;
    }

}