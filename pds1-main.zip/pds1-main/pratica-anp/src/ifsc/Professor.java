package ifsc;
public class Professor extends Pessoa {
	
	
		
		public Integer siape;
		
		public Integer getSiape() {
			 
		    return siape;
		    
		    }


		    public void setSiape(Integer siape) {
		        this.siape = siape;
		    }


		}

